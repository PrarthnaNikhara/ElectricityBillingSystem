package com.electricitybillingsystem;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class MeterInfo extends JFrame implements ActionListener {

    JTextField tfname,tfaddress,tfcity,tfstate,tfemail,tfphoneno;
    JButton next, cancel;
    JLabel lblmeter;
    Choice meterlocation,  metertype, phasecode, billtype;
    String meternumber;
    MeterInfo(String meternumber)
    {
        this.meternumber = meternumber;

        setSize(700,500);
        setLocation(400,200);

        JPanel p=new JPanel();
        p.setLayout(null);
        p.setBackground(new Color(173,216,230));
        add(p);


        JLabel heading=new JLabel("Meter Information");
        heading.setBounds(180,10,200,20);
        heading.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(heading);


        JLabel lblname=new JLabel("Meter Number");
        lblname.setBounds(100,80,200,20);
        // lblname.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblname);


        JLabel lblmeternumber=new JLabel(meternumber);
        lblmeternumber.setBounds(240,80,200,20);
        // lblmeternumber.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblmeternumber);



        JLabel lblmeterlocation=new JLabel("Meter Location");
        lblmeterlocation.setBounds(100,120,100,20);
        // lblmeterlocation.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblmeterlocation);

        meterlocation = new Choice();
        meterlocation.add("Outside");
        meterlocation.add("Inside");
        meterlocation.setBounds(240,160,200,20);
        p.add(meterlocation);



        JLabel lbladdress=new JLabel("Meter Type");
        lbladdress.setBounds(100,160,100,20);
        p.add(lbladdress);


        metertype = new Choice();
        metertype.add("Electric Meter");
        metertype.add("Solar Meter");
        metertype.add("Smart Meter");
        metertype.setBounds(240,160,200,20);
        p.add( metertype);


        JLabel lblcity=new JLabel("Phase Code");
        lblcity.setBounds(100,200,100,20);
        //  lblcity.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblcity);


        phasecode = new Choice();
        phasecode.add("011");
        phasecode.add("022");
        phasecode.add("033");
        phasecode.add("044");
        phasecode.add("055");
        phasecode.add("066");
        phasecode.add("077");
        phasecode.add("088");
        phasecode.add("099");
        phasecode.setBounds(240,200,200,20);
        p.add(phasecode);



        JLabel lblstate=new JLabel("Bill Type");
        lblstate.setBounds(100,240,100,20);
        //  lblstate.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblstate);


        billtype = new Choice();
        billtype.add("Normal");
        billtype.add("Industrial");
        billtype.setBounds(240,240,200,20);
        p.add( billtype);


        JLabel lblemail=new JLabel("Days");
        lblemail.setBounds(100,280,100,20);
        //  lblemail.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblemail);

        JLabel lblemails=new JLabel("30 Days");
        lblemails.setBounds(240,280,100,20);
        //  lblemails.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblemails);


        JLabel lblphoneno=new JLabel("Note");
        lblphoneno.setBounds(100,320,100,20);
        //  lblphoneno.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblphoneno);

        JLabel lblphonenos=new JLabel("By Default Bill is calculates for 30 Days only ");
        lblphonenos.setBounds(240,320,250,20);
        //  lblphonenos.setFont(new Font("Tahoma", Font.PLAIN,24));
        p.add(lblphonenos);


        next = new JButton(("Submit"));
        next.setBounds(220,390,100,25);
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        p.add(next);




        setLayout(new BorderLayout());

        add(p,"Center");

        ImageIcon i1= new ImageIcon((ClassLoader.getSystemResource("icon/hicon1.jpg")));
        Image i2= i1.getImage().getScaledInstance(150,300,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        add(image,"West");


        getContentPane().setBackground(Color.WHITE);

        setVisible(true);
    }


    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == next){
            String meter = meternumber;
            String location = meterlocation.getSelectedItem();
            String type = metertype.getSelectedItem();
            String code = phasecode.getSelectedItem();
            String typebill = billtype.getSelectedItem();
            String days = "30";

            String query="insert into meter_info values('"+meter+"', '"+location+"', '"+type+"', '"+code+"', '"+typebill+"', '"+days+"')";


            try{
                Conn c = new Conn();
                c.s.executeUpdate(query);

                JOptionPane.showMessageDialog(null,"Meter Information Added Successfully");
                setVisible(false);

                //new frame
            }
            catch (Exception e){
                e.printStackTrace();
            }

        } else{
            setVisible(false);
        }
    }

    public static void main(String[] args){
        new MeterInfo("");
    }
}


/*mysql
9.
select * from login;

create table customer (name varchar(20) , meter_no varchar(20)) , address varchar(50) , city varchar(30) , state varchar(30) , phone_no varchar(20) , email varchar(30));

select * from customer;

create table meter_info(meter_number varchar(20) , meter_location varchar(20), meter_type varchar(20), phase_code varchar(20), bill_type varchar(20), days varchar(20));

select * from meter_info;

create table tax(cost_per_unit varchar(20), meter_rent varchar(20), service_charge varchar(20), service_tax(20), swacch bharat varchar(20),

insert into tax values('9','47','22','57','6','18');

create table bill(meter_no varchar(20), month varchar(30), units varchar(20), totalbill varchar(20), status varchar(20));

select * from bill;

 */