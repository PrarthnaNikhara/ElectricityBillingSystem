package com.electricitybillingsystem;

import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;

public class DepositDetails extends JFrame{

Choice  meternumber,cmonth;
JTable table;
    DepositDetails(){
super("Deposit Details");

setSize(700,700);
setLocation(400,100);

setLayout(null);
getContentPane().setBackground(Color.WHITE);

JLabel lblmeternumber = new JLabel ("Search By Meter Number");
lblmeternumber.setBounds(20,20,150,20);
add(lblmeternumber);


meternumber=new Choice();
meternumber.setBounds(180,20,150,20);
add(meternumber);


try{
Conn c=new Conn();
ResultSet rs=c.s.executeQuery("select * from customer");
while(rs.next()){
    meternumber.add(rs.getString("meter_no"));
}
}catch(Exception e){
    e.printStackTrace();
}


        JLabel lblmonth = new JLabel ("Search By Month");
        lblmonth.setBounds(400,20,100,20);
        add(lblmonth);


        cmonth=new Choice();
        cmonth.setBounds(520,20,150,20);
        cmonth.add("January");
        cmonth.add("February");
        cmonth.add("March");
        cmonth.add("April");
        cmonth.add("May");
        cmonth.add("June");
        cmonth.add("July");
        cmonth.add("August");
        cmonth.add("September");
        cmonth.add("October");
        cmonth.add("November");
        cmonth.add("December");
        add(cmonth);



        table =new JTable();

        try{
Conn c =new Conn();
            ResultSet rs=c.s.executeQuery("select  from bill");

        } catch(Exception e){
            e.printStackTrace();
        }


setVisible(true);
    }


    public static void main(String[] args){
        new DepositDetails();
    }

}
